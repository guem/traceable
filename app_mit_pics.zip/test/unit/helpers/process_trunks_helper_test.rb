require 'test_helper'

class ProcessTrunksHelperTest < ActionView::TestCase
end
