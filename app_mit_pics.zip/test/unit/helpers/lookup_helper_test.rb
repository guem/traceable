require 'test_helper'

class LookupHelperTest < ActionView::TestCase
end
