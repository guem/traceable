require 'test_helper'

class TrunksHelperTest < ActionView::TestCase
end
