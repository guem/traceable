class RemoveSpeciesFromTrunk < ActiveRecord::Migration
  def self.up
    remove_column :trunks, :species
  end

  def self.down
    add_column :trunks, :species
  end
end
