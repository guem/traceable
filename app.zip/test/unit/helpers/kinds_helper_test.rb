require 'test_helper'

class KindsHelperTest < ActionView::TestCase
end
