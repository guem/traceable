class Kind < ActiveRecord::Base

  validates_presence_of :portugues
  validates_uniqueness_of :scientific,
        :message => "Scientific name must be unique"

  has_many :trunks

  has_attached_file :picture,
        :styles => { :medium => "150x150>",
        :thumb => "80x80>" }

end
