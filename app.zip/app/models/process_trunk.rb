class ProcessTrunk < ActiveRecord::Base

  validates_presence_of :trunk_id

  belongs_to :trunk

  def kind
    trunk.kind
  end

  def traceable
    trunk.traceable
  end

end
