module KindsHelper

end
